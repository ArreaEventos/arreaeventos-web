# Web de Arrea Eventos — guía de edición

## Estructura
```
index.html          Contenido (textos, secciones)
css/styles.css      Estilos (colores, tipografía, diseño)
js/main.js          Comportamiento (modal, WhatsApp, animaciones)
assets/img/         Todas las imágenes, con nombre descriptivo
assets/favicon/     Iconos de la web (pestaña del navegador, iPhone, Android)
favicon.ico         Icono clásico (debe quedarse en la raíz, junto a index.html)
```
Para verla: abre `index.html` en el navegador (no necesita servidor).

## Qué tocar para cada cambio
| Quiero cambiar…                    | Dónde                                                      |
|------------------------------------|------------------------------------------------------------|
| Colores de marca                   | `css/styles.css` → bloque `:root` (arriba del todo)        |
| Titular, tagline, textos           | `index.html` → `<section class="hero">`, `#nosotros`…      |
| Descripción de un servicio (modal) | `index.html` → atributo `data-desc` de la tarjeta. Los párrafos se separan con `\|\|` |
| Añadir un servicio                 | Copiar una `<div class="service-card …">`, cambiar `data-title`, número, `<h3>` e imagen (y añadirlo en el `<select>` del formulario) |
| Contenido de un paquete            | `index.html` → `<ul class="pkg-list">` de cada `pkg-card`  |
| Cifras (120+, 15, 98%)             | `index.html` → bloque `.stats`                             |
| Añadir/quitar un trabajo del carrusel | `index.html` → dentro de `.gallery-track`, copiar o borrar un `<div class="gtile g-photo">`. Los puntos y las copias del bucle circular se crean solos. Velocidad del avance automático: `AUTOPLAY_MS` en `js/main.js` (0 = apagado) |
| Fotos                              | Sustituir el archivo en `assets/img/` manteniendo el nombre|
| Foto de fondo de los paquetes      | `css/styles.css` → `.pkg-card:nth-child(N)::before`        |
| Contacto / teléfono / WhatsApp     | `index.html` → sección `#contacto` y `.wa-widget` (número en formato `34983220818`) |
| Icono de la pestaña (favicon)      | Sustituir los archivos de `assets/favicon/` y `favicon.ico` manteniendo nombres y tamaños (16, 32, 48, 180, 192, 512 px) |
| Redes sociales                     | `index.html` → `.social-row` del footer                    |

## Pendiente antes de publicar
1. **Formulario de contacto**: ahora solo simula el envío ("Enviado ✓"). Hay que conectarlo (Formspree, Netlify Forms, backend propio…) y quitar la nota "Vista previa de la maqueta".
2. **Pie de página**: sigue diciendo "empresa simulada con fines educativos".
3. **Imágenes**: ~200–300 KB cada una; se pueden pasar a WebP para ganar velocidad.
4. **Animación `.reveal`** definida dos veces en el CSS (la segunda, desde la izquierda, es la que se aplica). Conviene dejar solo una.
5. Añadir `<meta name="description">`, favicon e imagen Open Graph para SEO y compartir en redes.
