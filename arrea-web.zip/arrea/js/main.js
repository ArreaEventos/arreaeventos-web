(function(){
    var els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) {
      els.forEach(function(el){ el.classList.add('is-visible'); });
      return;
    }
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    els.forEach(function(el){ io.observe(el); });
  })();
  (function(){
    var photo = document.querySelector('.hero-photo');
    if (!photo) return;
    var heroSection = document.querySelector('.hero');
    if (!('IntersectionObserver' in window)) {
      photo.classList.add('is-color');
      return;
    }
    var io2 = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting) {
          photo.classList.add('is-color');
        } else {
          photo.classList.remove('is-color');
        }
      });
    }, { threshold: 0.3 });
    io2.observe(heroSection);
  })();
  (function(){
    var toggles = document.querySelectorAll('.pkg-toggle');
    toggles.forEach(function(btn){
      btn.addEventListener('click', function(){
        var list = btn.nextElementSibling;
        var isOpen = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', String(!isOpen));
        list.classList.toggle('is-open', !isOpen);
        var label = btn.querySelector('span');
        label.textContent = isOpen ? 'Ver qué incluye' : 'Ocultar';
      });
    });
  })();

(function(){
    var bubble=document.getElementById('waBubble');
    var closeBtn=document.getElementById('waClose');
    if(!bubble) return;
    var timer=setTimeout(function(){ bubble.classList.add('is-open'); }, 3500);
    closeBtn.addEventListener('click', function(){
      clearTimeout(timer);
      bubble.classList.remove('is-open');
    });
  })();

  (function(){
    var cards=document.querySelectorAll('.service-card--photo');
    var modal=document.getElementById('serviceModal');
    var modalImg=document.getElementById('serviceModalImg');
    var modalTitle=document.getElementById('serviceModalTitle');
    var modalText=document.getElementById('serviceModalText');
    var closeBtn=document.getElementById('serviceModalClose');
    if(!modal) return;
    function openModal(card){
      var img=card.querySelector('.service-photo img');
      var title=card.getAttribute('data-title') || (card.querySelector('h3')||{}).textContent || '';
      var desc=card.getAttribute('data-desc') || '';
      if(img) modalImg.style.backgroundImage="url('"+img.src+"')";
      modalTitle.textContent=title;
      modalText.innerHTML=desc.split('||').map(function(p){ return '<p>'+p+'</p>'; }).join('');
      var mb=document.getElementById('serviceModalBody'); if(mb) mb.scrollTop=0;
      modal.classList.add('is-open');
      document.body.style.overflow='hidden';
    }
    function closeModal(){ modal.classList.remove('is-open'); document.body.style.overflow=''; }
    cards.forEach(function(card){
      card.setAttribute('tabindex','0');
      card.setAttribute('role','button');
      card.setAttribute('aria-haspopup','dialog');
      card.addEventListener('click', function(){ openModal(card); });
      card.addEventListener('keydown', function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); openModal(card); } });
    });
    closeBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', function(e){ if(e.target===modal) closeModal(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeModal(); });
  })();
  (function(){
    var tiles=document.querySelectorAll('.g-photo');
    tiles.forEach(function(tile){
      tile.addEventListener('click', function(){
        if(window.matchMedia('(hover:none)').matches){
          tile.classList.toggle('is-active');
        }
      });
    });
  })();
  (function(){
    var pkgCards=document.querySelectorAll('.pkg-card');
    pkgCards.forEach(function(card){
      card.addEventListener('click', function(e){
        if(window.matchMedia('(hover:none)').matches && !e.target.closest('.pkg-toggle')){
          pkgCards.forEach(function(c){ if(c!==card) c.classList.remove('is-active'); });
          card.classList.toggle('is-active');
        }
      });
    });
  })();

/* Número de asistentes: máximo 100 (flechas, teclado y pegado) */
(function(){
  var input = document.getElementById('asistentes');
  if(!input) return;
  var MAX = 100, MIN = 1;
  function clamp(){
    if(input.value === '') return;
    var v = Math.floor(Number(input.value));
    if(isNaN(v)) { input.value = ''; return; }
    if(v > MAX) v = MAX;
    if(v < MIN) v = MIN;
    input.value = v;
  }
  input.addEventListener('input', clamp);
  input.addEventListener('change', clamp);
  input.addEventListener('keydown', function(e){
    if(e.key === '-' || e.key === '+' || e.key === 'e' || e.key === 'E' || e.key === '.' || e.key === ','){ e.preventDefault(); }
  });
})();

/* Aviso de cookies: se muestra al entrar y recuerda la decisión 12 meses */
(function(){
  var KEY = 'arrea_cookie_consent', DAYS = 365;
  var popup = document.getElementById('cookiePopup');
  if(!popup) return;
  var more = document.getElementById('cookieMore');
  var details = document.getElementById('cookieDetails');

  function read(){
    try{
      var d = JSON.parse(localStorage.getItem(KEY));
      if(d && (Date.now() - d.ts) < DAYS*864e5) return d;
    }catch(e){}
    return null;
  }
  function save(choice){
    try{ localStorage.setItem(KEY, JSON.stringify({choice:choice, ts:Date.now()})); }catch(e){}
    /* Punto de enganche: aquí se activarían las analíticas solo si choice === 'all' */
    window.arreaCookieConsent = choice;
    document.dispatchEvent(new CustomEvent('cookieconsent', {detail:{choice:choice}}));
  }
  function open(){
    popup.hidden = false;
    document.body.classList.add('cookie-open');
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ popup.classList.add('is-open'); }); });
  }
  function close(){
    popup.classList.remove('is-open');
    document.body.classList.remove('cookie-open');
    setTimeout(function(){ popup.hidden = true; }, 500);
  }
  function choose(choice){ save(choice); close(); }

  document.getElementById('cookieAccept').addEventListener('click', function(){ choose('all'); });
  document.getElementById('cookieReject').addEventListener('click', function(){ choose('necessary'); });
  document.getElementById('cookieClose').addEventListener('click', function(){ choose('necessary'); });
  more.addEventListener('click', function(){
    var o = more.getAttribute('aria-expanded') === 'true';
    more.setAttribute('aria-expanded', String(!o));
    details.classList.toggle('is-open', !o);
  });
  var link = document.getElementById('cookieSettings');
  if(link) link.addEventListener('click', open);

  var saved = read();
  if(saved){ window.arreaCookieConsent = saved.choice; }
  else { setTimeout(open, 700); }
})();
