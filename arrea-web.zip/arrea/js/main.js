(function(){
    var els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) {
      els.forEach(function(el){ el.classList.add('is-visible'); });
      return;
    }
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    els.forEach(function(el){ io.observe(el); });
  })();
  (function(){
    var photo = document.querySelector('.hero-photo');
    if (!photo) return;
    var heroSection = document.querySelector('.hero');
    if (!('IntersectionObserver' in window)) {
      photo.classList.add('is-color');
      return;
    }
    var io2 = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting) {
          photo.classList.add('is-color');
        } else {
          photo.classList.remove('is-color');
        }
      });
    }, { threshold: 0.3 });
    io2.observe(heroSection);
  })();
  (function(){
    var toggles = document.querySelectorAll('.pkg-toggle');
    toggles.forEach(function(btn){
      btn.addEventListener('click', function(){
        var list = btn.nextElementSibling;
        var isOpen = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', String(!isOpen));
        list.classList.toggle('is-open', !isOpen);
        var label = btn.querySelector('span');
        label.textContent = isOpen ? 'Ver qué incluye' : 'Ocultar';
      });
    });
  })();

(function(){
    var bubble=document.getElementById('waBubble');
    var closeBtn=document.getElementById('waClose');
    if(!bubble) return;
    var timer=setTimeout(function(){ bubble.classList.add('is-open'); }, 3500);
    closeBtn.addEventListener('click', function(){
      clearTimeout(timer);
      bubble.classList.remove('is-open');
    });
  })();

  (function(){
    var cards=document.querySelectorAll('.service-card--photo');
    var modal=document.getElementById('serviceModal');
    var modalImg=document.getElementById('serviceModalImg');
    var modalTitle=document.getElementById('serviceModalTitle');
    var modalText=document.getElementById('serviceModalText');
    var closeBtn=document.getElementById('serviceModalClose');
    if(!modal) return;
    function openModal(card){
      var img=card.querySelector('.service-photo img');
      var title=card.getAttribute('data-title') || (card.querySelector('h3')||{}).textContent || '';
      var desc=card.getAttribute('data-desc') || '';
      if(img) modalImg.style.backgroundImage="url('"+img.src+"')";
      modalTitle.textContent=title;
      modalText.innerHTML=desc.split('||').map(function(p){ return '<p>'+p+'</p>'; }).join('');
      var mb=document.getElementById('serviceModalBody'); if(mb) mb.scrollTop=0;
      modal.classList.add('is-open');
      document.body.style.overflow='hidden';
    }
    function closeModal(){ modal.classList.remove('is-open'); document.body.style.overflow=''; }
    cards.forEach(function(card){
      card.setAttribute('tabindex','0');
      card.setAttribute('role','button');
      card.setAttribute('aria-haspopup','dialog');
      card.addEventListener('click', function(){ openModal(card); });
      card.addEventListener('keydown', function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); openModal(card); } });
    });
    closeBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', function(e){ if(e.target===modal) closeModal(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeModal(); });
  })();
  (function(){
    var pkgCards=document.querySelectorAll('.pkg-card');
    pkgCards.forEach(function(card){
      card.addEventListener('click', function(e){
        if(window.matchMedia('(hover:none)').matches && !e.target.closest('.pkg-toggle')){
          pkgCards.forEach(function(c){ if(c!==card) c.classList.remove('is-active'); });
          card.classList.toggle('is-active');
        }
      });
    });
  })();

/* Número de asistentes: máximo 100 (flechas, teclado y pegado) */
(function(){
  var input = document.getElementById('asistentes');
  if(!input) return;
  var MAX = 100, MIN = 1;
  function clamp(){
    if(input.value === '') return;
    var v = Math.floor(Number(input.value));
    if(isNaN(v)) { input.value = ''; return; }
    if(v > MAX) v = MAX;
    if(v < MIN) v = MIN;
    input.value = v;
  }
  input.addEventListener('input', clamp);
  input.addEventListener('change', clamp);
  input.addEventListener('keydown', function(e){
    if(e.key === '-' || e.key === '+' || e.key === 'e' || e.key === 'E' || e.key === '.' || e.key === ','){ e.preventDefault(); }
  });
})();

/* Aviso de cookies: se muestra al entrar y recuerda la decisión 12 meses */
(function(){
  var KEY = 'arrea_cookie_consent', DAYS = 365;
  var popup = document.getElementById('cookiePopup');
  if(!popup) return;
  var more = document.getElementById('cookieMore');
  var details = document.getElementById('cookieDetails');

  function read(){
    try{
      var d = JSON.parse(localStorage.getItem(KEY));
      if(d && (Date.now() - d.ts) < DAYS*864e5) return d;
    }catch(e){}
    return null;
  }
  function save(choice){
    try{ localStorage.setItem(KEY, JSON.stringify({choice:choice, ts:Date.now()})); }catch(e){}
    /* Punto de enganche: aquí se activarían las analíticas solo si choice === 'all' */
    window.arreaCookieConsent = choice;
    document.dispatchEvent(new CustomEvent('cookieconsent', {detail:{choice:choice}}));
  }
  function open(){
    popup.hidden = false;
    document.body.classList.add('cookie-open');
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ popup.classList.add('is-open'); }); });
  }
  function close(){
    popup.classList.remove('is-open');
    document.body.classList.remove('cookie-open');
    setTimeout(function(){ popup.hidden = true; }, 500);
  }
  function choose(choice){ save(choice); close(); }

  document.getElementById('cookieAccept').addEventListener('click', function(){ choose('all'); });
  document.getElementById('cookieReject').addEventListener('click', function(){ choose('necessary'); });
  document.getElementById('cookieClose').addEventListener('click', function(){ choose('necessary'); });
  more.addEventListener('click', function(){
    var o = more.getAttribute('aria-expanded') === 'true';
    more.setAttribute('aria-expanded', String(!o));
    details.classList.toggle('is-open', !o);
  });
  var link = document.getElementById('cookieSettings');
  if(link) link.addEventListener('click', open);

  var saved = read();
  if(saved){ window.arreaCookieConsent = saved.choice; }
  else { setTimeout(open, 700); }
})();

/* Menú móvil: abrir/cerrar con el botón, al elegir una opción, con Esc o al tocar fuera */
(function(){
  var header = document.querySelector('header');
  var btn = document.getElementById('navToggle');
  if(!header || !btn) return;
  function set(open){
    header.classList.toggle('menu-open', open);
    btn.setAttribute('aria-expanded', String(open));
    btn.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
  }
  btn.addEventListener('click', function(e){ e.stopPropagation(); set(!header.classList.contains('menu-open')); });
  header.querySelectorAll('.nav-links a').forEach(function(a){ a.addEventListener('click', function(){ set(false); }); });
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape') set(false); });
  document.addEventListener('click', function(e){ if(!header.contains(e.target)) set(false); });
  window.addEventListener('resize', function(){ if(window.innerWidth > 720) set(false); });
})();

/* Carrusel de "Trabajos recientes": circular (sin fin), con flechas, puntos, deslizar, teclado y avance automático */
(function(){
  var AUTOPLAY_MS = 5500;                 /* poner 0 para desactivar el avance automático */
  var root = document.getElementById('worksCarousel');
  if(!root) return;
  var track = root.querySelector('.gallery-track');
  var slides = Array.prototype.slice.call(track.children);     /* las fotos reales */
  var N = slides.length;
  if(N < 2) return;
  var K = N;                                                   /* copias a cada lado: permiten dar la vuelta aunque se pulse muy rápido */
  var prev = root.querySelector('.car-prev'), next = root.querySelector('.car-next');
  var dotsBox = root.querySelector('.car-dots');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* copias: las últimas fotos antes de la primera y las primeras después de la última */
  function copyOf(s){
    var c = s.cloneNode(true);
    c.classList.add('is-clone');
    c.removeAttribute('role'); c.removeAttribute('aria-roledescription'); c.removeAttribute('aria-label');
    c.setAttribute('aria-hidden', 'true');
    return c;
  }
  var first = slides[0], k;
  for(k = 0; k < K; k++) track.insertBefore(copyOf(slides[N - K + k]), first);
  for(k = 0; k < K; k++) track.appendChild(copyOf(slides[k]));
  var all = Array.prototype.slice.call(track.children);
  function realOf(a){ return ((a - K) % N + N) % N; }

  var current = 0;          /* foto real que se está viendo (0..N-1) */
  var curAll = K;           /* posición dentro de "all" (con copias) */
  var target = K;           /* a dónde se dirige el desplazamiento */
  var timer = null, userTookOver = false, inView = false, hovering = false, touching = false, dragging = false;
  var programmatic = false, progAt = 0;   /* true mientras se desplaza hacia un destino (botones, puntos, teclado, automático) */

  var dots = slides.map(function(s, i){
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'car-dot';
    var cap = s.querySelector('span');
    b.setAttribute('aria-label', 'Ir al trabajo ' + (i+1) + ' de ' + N + (cap ? ': ' + cap.textContent : ''));
    b.addEventListener('click', function(){ userTookOver = true; stop(); goToReal(i); });
    dotsBox.appendChild(b); return b;
  });

  function setCurrent(r){
    current = r;
    all.forEach(function(s, a){ s.classList.toggle('is-current', realOf(a) === r); });
    dots.forEach(function(d, i){ if(i === r) d.setAttribute('aria-current','true'); else d.removeAttribute('aria-current'); });
  }
  function offsetFor(a){
    var s = all[a];
    return s.offsetLeft - (track.clientWidth - s.offsetWidth) / 2;
  }
  function scrollToAll(a, instant){
    a = Math.max(0, Math.min(all.length - 1, a));
    target = a; programmatic = true; progAt = Date.now();
    track.scrollTo({ left: offsetFor(a), behavior: (instant || reduce) ? 'auto' : 'smooth' });
    setCurrent(realOf(a));
  }
  function jumpTo(a){                      /* salto invisible: la copia y la foto real son idénticas */
    track.style.scrollSnapType = 'none';
    track.scrollLeft = offsetFor(a);
    curAll = target = a;
    requestAnimationFrame(function(){ track.style.scrollSnapType = ''; });
  }
  function nearestAll(){
    var center = track.scrollLeft + track.clientWidth / 2, best = 0, bd = 1e9;
    all.forEach(function(s, a){
      var d = Math.abs(s.offsetLeft + s.offsetWidth / 2 - center);
      if(d < bd){ bd = d; best = a; }
    });
    return best;
  }
  function rebase(sign){                   /* desplaza la vista N fotos sin que se note (las copias son idénticas) */
    var dist = all[N].offsetLeft - all[0].offsetLeft;
    track.style.scrollSnapType = 'none';
    track.scrollLeft -= sign * dist;
    target -= sign * N; curAll -= sign * N;
    requestAnimationFrame(function(){ track.style.scrollSnapType = ''; });
  }
  function step(d){
    var t = target + d;
    if(t >= all.length){ rebase(1); t -= N; }
    else if(t < 0){ rebase(-1); t += N; }
    scrollToAll(t);
  }
  function goToReal(i){                    /* va por el camino más corto, también dando la vuelta */
    var cands = [i + K - N, i + K, i + K + N].filter(function(a){ return a >= 0 && a < all.length; });
    var best = cands[0];
    cands.forEach(function(a){ if(Math.abs(a - target) < Math.abs(best - target)) best = a; });
    scrollToAll(best);
  }

  /* al terminar de moverse: si se está sobre una copia, salta a la foto real equivalente */
  var settleT = null;
  function scheduleSettle(){
    clearTimeout(settleT);
    settleT = setTimeout(function(){
      if(touching || dragging) return;
      if(programmatic){
        if(Math.abs(track.scrollLeft - offsetFor(target)) > 2 && Date.now() - progAt < 3000){ scheduleSettle(); return; }   /* aún va de camino */
        programmatic = false;
      }
      var a = nearestAll();
      if(a < K) jumpTo(a + N);
      else if(a >= N + K) jumpTo(a - N);
      else { curAll = target = a; }
    }, 150);
  }
  var raf = null;
  track.addEventListener('scroll', function(){
    if(!raf) raf = requestAnimationFrame(function(){
      raf = null;
      curAll = nearestAll();
      var r = realOf(curAll);
      if(!programmatic && r !== current) setCurrent(r);   /* si va hacia un destino, el punto ya marca el destino */
    });
    scheduleSettle();
  }, {passive:true});

  function interact(fn){ return function(){ userTookOver = true; stop(); fn(); }; }
  prev.addEventListener('click', interact(function(){ step(-1); }));
  next.addEventListener('click', interact(function(){ step(1); }));
  track.addEventListener('keydown', function(e){
    if(e.key === 'ArrowRight'){ e.preventDefault(); userTookOver = true; stop(); step(1); }
    else if(e.key === 'ArrowLeft'){ e.preventDefault(); userTookOver = true; stop(); step(-1); }
    else if(e.key === 'Home'){ e.preventDefault(); goToReal(0); }
    else if(e.key === 'End'){ e.preventDefault(); goToReal(N - 1); }
  });
  /* clic en una foto vecina: la trae al centro */
  all.forEach(function(s, a){ s.addEventListener('click', function(){ if(a !== curAll){ userTookOver = true; stop(); scrollToAll(a); } }); });
  /* arrastrar con el ratón en ordenador */
  var startX = 0, startLeft = 0, moved = false;
  track.addEventListener('pointerdown', function(e){
    if(e.pointerType !== 'mouse') return;
    dragging = true; programmatic = false; moved = false; startX = e.clientX; startLeft = track.scrollLeft;
  });
  window.addEventListener('pointermove', function(e){
    if(!dragging) return;
    var dx = e.clientX - startX;
    if(Math.abs(dx) > 5){ moved = true; track.style.scrollSnapType = 'none'; track.style.cursor = 'grabbing'; track.scrollLeft = startLeft - dx; }
  });
  window.addEventListener('pointerup', function(){
    if(!dragging) return; dragging = false;
    track.style.cursor = ''; track.style.scrollSnapType = '';
    if(moved){ userTookOver = true; stop(); scrollToAll(nearestAll()); }
  });
  track.addEventListener('click', function(e){ if(moved){ e.stopPropagation(); moved = false; } }, true);
  track.addEventListener('touchstart', function(){ touching = true; programmatic = false; userTookOver = true; stop(); }, {passive:true});
  track.addEventListener('touchend', function(){ touching = false; scheduleSettle(); }, {passive:true});
  track.addEventListener('touchcancel', function(){ touching = false; scheduleSettle(); }, {passive:true});

  /* avance automático: siempre hacia delante, dando la vuelta sin rebobinar */
  function tick(){
    if(!inView || hovering || document.hidden || userTookOver) return;
    step(1);
  }
  function start(){ if(AUTOPLAY_MS > 0 && !reduce && !userTookOver && !timer) timer = setInterval(tick, AUTOPLAY_MS); }
  function stop(){ if(timer){ clearInterval(timer); timer = null; } }
  root.addEventListener('mouseenter', function(){ hovering = true; });
  root.addEventListener('mouseleave', function(){ hovering = false; });
  root.addEventListener('focusin', function(){ hovering = true; });
  root.addEventListener('focusout', function(){ hovering = false; });
  if('IntersectionObserver' in window){
    new IntersectionObserver(function(en){ inView = en[0].isIntersecting; }, {threshold:0.5}).observe(root);
  } else { inView = true; }

  function reset(){ programmatic = false; jumpTo(current + K); }
  window.addEventListener('resize', reset);
  setCurrent(0);
  reset();
  window.addEventListener('load', reset);
  start();
})();
